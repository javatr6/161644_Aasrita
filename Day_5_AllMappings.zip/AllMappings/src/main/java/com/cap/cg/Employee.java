package com.cap.cg;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	@Id
	private int employeeId;
	private String employeeName;
	@ManyToOne
	@JoinColumn(name="companypk")
	private Company company;
	private LocalDate doj;
	public Employee() {
		
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", company=" + company
				+ ", doj=" + doj + "]";
	}
	public Employee(int employeeId, String employeeName, Company company, LocalDate doj) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.company = company;
		this.doj = doj;
	}
	
}
