package com.capgemini.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Mainclass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
        transaction.begin();
        
        Project project=new Project(1001,"CitiBank");
        
        module Module=new module();
        Module.setProjectId(121);
        Module.setProjectName("TransUnion");
        Module.setModuleName("LoginModule");
        
        Task task=new Task();
        task.setProjectId(1009);
        task.setProjectName("Discover");
        task.setModuleName("Validation");
        task.setTaskName("Client side Validation");
        
        
        entityManager.persist(project);
        entityManager.persist(Module);
        entityManager.persist(task);
        
        transaction.commit();
        entityManager.close();
	}

}
