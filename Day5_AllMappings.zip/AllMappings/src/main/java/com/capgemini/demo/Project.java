package com.capgemini.demo;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
@Entity
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Project {
	@Id
private int ProjectId; 
private String ProjectName;
private LocalDate date=LocalDate.now();


public Project() {
	
}


public LocalDate getDate() {
	return date;
}


public void setDate(LocalDate date) {
	this.date = date;
}


public Project(int projectId, String projectName) {
	super();
	ProjectId = projectId;
	ProjectName = projectName;
}


public int getProjectId() {
	return ProjectId;
}


public void setProjectId(int projectId) {
	ProjectId = projectId;
}


public String getProjectName() {
	return ProjectName;
}


public void setProjectName(String projectName) {
	ProjectName = projectName;
}


@Override
public String toString() {
	return "Project [ProjectId=" + ProjectId + ", ProjectName=" + ProjectName + "]";
}

}

