package com.cap.om;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {

	@Id
	private int addressId;
	private String address;
	private LocalDate date;
	
	@OneToOne
	@JoinColumn(name="custFk")
	private Customer customer;
	
	public Address() {
		
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", address=" + address + ", date=" + date + ", customer=" + customer
				+ "]";
	}

	public Address(int addressId, String address, LocalDate date, Customer customer) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.date = date;
		this.customer = customer;
	}

}