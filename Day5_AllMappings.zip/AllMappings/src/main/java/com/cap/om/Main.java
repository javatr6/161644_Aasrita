package com.cap.om;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		
		transaction.begin();
		
		Customer avinash= new Customer("AASRITA","SRIPARTI",15600);
		Address address= new Address(1001,"Mahindra World",LocalDate.now(),avinash);
		em.persist(avinash);
		em.persist(address);
		transaction.commit();
		em.close();
	}
}