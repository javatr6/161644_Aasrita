package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webDriver;
	private WebElement webElement;
	

	@Before
	public void setUp(){
		System.setProperty("webdriver.chrome.driver", "C:\\selinum\\chromedriver.exe");
		webDriver=new ChromeDriver();

	}
	
	@Given("^loginpage$")
	public void loginpage() throws Throwable {
		webDriver.get("file:///C:/Users/asripart/Desktop/hotelBooking/login.html");
	}

	@When("^For valid  and capg(\\d+)$")
	public void for_valid_and_capg(int arg1) throws Throwable {
		webDriver.findElement(By.name("userName")).sendKeys("");
		Thread.sleep(1000);
		webDriver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(1000);

	}

	@Then("^login into account with  and capg(\\d+)$")
	public void login_into_account_with_and_capg(int arg1) throws Throwable {
		webElement=webDriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input"));
		webElement.click();
		Thread.sleep(2000);
				
	}

	@When("^For valid capgemini and $")
	public void for_valid_capgemini_and() throws Throwable {
		webDriver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);
		webDriver.findElement(By.name("userPwd")).sendKeys("");
		Thread.sleep(1000);
	}

	@Then("^login into account with capgemini and $")
	public void login_into_account_with_capgemini_and() throws Throwable {
		webElement=webDriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input"));
		webElement.click();
		Thread.sleep(2000);
	}

	@When("^For valid capgemini and capg(\\d+)$")
	public void for_valid_capgemini_and_capg(int arg1) throws Throwable {
		webDriver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);
		webDriver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(1000);
	}

	@Then("^login into account with capgemini and capg(\\d+)$")
	public void login_into_account_with_capgemini_and_capg(int arg1) throws Throwable {
		webElement=webDriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input"));
		webElement.click();
		webDriver.navigate().to("file:///C:/Users/asripart/Desktop/hotelBooking/hotelbooking.html");
		Thread.sleep(1000);	
	}

	@After
	public void TearDown() {
		webDriver.quit();
	}
	
}
