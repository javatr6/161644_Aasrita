package com.service;

import com.model.LoginBean;

public interface ILoginService {
	
public abstract boolean checkUser(LoginBean loginBean);
}