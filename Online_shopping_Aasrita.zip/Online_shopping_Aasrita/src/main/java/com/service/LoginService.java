package com.service;

import com.cap.dao.ILoginDao;
import com.cap.dao.LoginDao;
import com.model.LoginBean;



public class LoginService implements ILoginService {
	private ILoginDao loginDao = new LoginDao();
	
	@Override
	public boolean checkUser(LoginBean loginBean) {
		if(loginDao.checkUser(loginBean)) {
			return true;
		}else {
			return false;
		}
		
	}

	

	
}
