package com.cap.dao;

import com.model.LoginBean;

public interface ILoginDao {
	
	 public  boolean checkUser(LoginBean loginBean);
}
