package com.capgemini;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.LoginBean;
import com.service.ILoginService;
import com.service.LoginService;


@WebServlet("/ShoppingServlet")
public class ShoppingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	LoginBean loginbean=new LoginBean();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter pw = response.getWriter();
		String username = request.getParameter("userName");
		String password = request.getParameter("userPwd");
		LoginBean loginBean=new LoginBean(username,password);
		ILoginService loginService = new LoginService();
		if(loginService.checkUser(loginBean)) {
			response.sendRedirect("pages/success.html");
		}
		else {
			pw.println(username+" "+password );
			pw.println("not an authorized user");
            RequestDispatcher rd=request.getRequestDispatcher("index.html");
            rd.include(request, response);    
		}
	}
}